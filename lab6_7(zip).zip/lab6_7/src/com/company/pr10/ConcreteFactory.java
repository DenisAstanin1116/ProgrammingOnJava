package com.company.pr10;

import java.util.ArrayList;

public class ConcreteFactory implements ComplexAbstractFactory{

    private ArrayList<Complex> complexes = new ArrayList<>();
    @Override
    public Complex createComplex() {
        Complex complex = new Complex();
        complexes.add(complex);
        return  complex;
    }

    @Override
    public Complex createComplex(int real, int image) {
        Complex complex = new Complex(real, image);
        complexes.add(complex);
        return complex;
    }

    public String toString(){
        String res = "";
        for (int i = 0; i < complexes.size(); i++) res+=complexes.get(i).toString() + "\n";
        return res;
    }
}
