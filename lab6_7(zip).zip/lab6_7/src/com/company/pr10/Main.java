package com.company.pr10;

import com.company.Lab7.Run;

public class Main {

    public static void main(String[] args) {
        ConcreteFactory concreteFactory = new ConcreteFactory();
        concreteFactory.createComplex(4, 1);
        concreteFactory.createComplex(15,23);
        System.out.print(concreteFactory);
    }
}
