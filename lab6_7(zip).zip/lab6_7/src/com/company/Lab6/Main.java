package com.company.Lab6;

import com.company.Lab6.GetImage;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
	// write your code here
        GetImage getImage = new GetImage();
        Scanner in = new Scanner(System.in);
        System.out.print("Directory: ");
        String dir = in.nextLine();
        getImage.start(dir);
    }
}
// C:\\Users\\denso\\Downloads\\picture2.png