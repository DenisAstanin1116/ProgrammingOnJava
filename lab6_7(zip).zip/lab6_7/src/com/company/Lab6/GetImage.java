package com.company.Lab6;

import javax.swing.*;
import java.awt.*;
import java.nio.file.Path;

public class GetImage extends JFrame {

    public void start(String dir){
        JLabel picture;
        JFrame jframe = new JFrame();
        JLabel jLabel = new JLabel();
        jframe.setTitle("Отображение картинки");
        jframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        jLabel.setLayout(new BorderLayout());
        Image img = Toolkit.getDefaultToolkit().createImage(Path.of(dir).toAbsolutePath().toString());
        ImageIcon imageIcon = new ImageIcon(img);
        imageIcon.setImageObserver(jLabel);
        jLabel.setIcon(imageIcon);
        jframe.setSize(imageIcon.getIconWidth(), imageIcon.getIconHeight());
        jframe.add(jLabel);
        jframe.setVisible(true);
    }
}
