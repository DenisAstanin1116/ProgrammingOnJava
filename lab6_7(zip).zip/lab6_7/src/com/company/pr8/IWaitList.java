package com.company.pr8;

import java.util.Collection;

public interface IWaitList <I>
{
    void add(I element);
    I remove();
    boolean contains(I element);
    boolean containsAll(Collection<I> c);
    boolean isEmpty();
}
