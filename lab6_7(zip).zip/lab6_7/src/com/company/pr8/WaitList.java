package com.company.pr8;

import java.util.ArrayList;
import java.util.Collection;
import java.util.concurrent.ConcurrentLinkedQueue;

public class WaitList <I> implements IWaitList <I>
{
    protected ConcurrentLinkedQueue<I> content;

    public WaitList()
    {
        content = new ConcurrentLinkedQueue<>();
    }

    public WaitList(Collection<I> c)
    {
        content = new ConcurrentLinkedQueue<>(c);
    }

    public String toString()
    {
        return "WaitList " + content;
    }

    @Override
    public void add(I element)
    {
        content.add(element);
    }

    @Override
    public I remove()
    {
        if (isEmpty()) {
            System.out.println("Очередь пуста");
            System.exit(0);
        }
        return content.remove();
    }

    @Override
    public boolean contains(I element)
    {
        boolean flag = false;
        for (int i = 0; i < content.size(); i++)
        {
            I el = content.remove();
            if (el.equals(element)) {
                flag = true;
            }
            content.add(el);
        }
        return flag;
    }

    @Override
    public boolean containsAll(Collection<I> c)
    {
        ArrayList<I> el = new ArrayList<>(c);

        for (int i = 0; i < c.size(); i++)
        {
            boolean flag = false;
            for (int j = 0; j < content.size(); j++)
            {
                I elem = content.remove();
                if (elem.equals(el.get(i))) {
                    flag = true;
                }
                content.add(elem);
            }

            if (!flag) {
                return false;
            }
        }
        return true;
    }

    @Override
    public boolean isEmpty()
    {
        return content.isEmpty();
    }
}
