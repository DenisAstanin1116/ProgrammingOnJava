package com.company.pr8;

import java.util.ArrayList;

public class UnfairWaitList <I> extends WaitList<I>
{
    ArrayList<I> oldNums = new ArrayList<>();

    @Override
    public void add(I element) {
        for (int i = 0; i < oldNums.size(); i++) {
            if (oldNums.contains(element)) {
                System.out.println("Нельзя вводить введенные до этого числа");
                System.exit(0);
            }
        }
        content.add(element);
    }

    public UnfairWaitList()
    {
        super();
    }

    public void remove(I element)
    {
        boolean flag = false;

        for(int i = 0; i < this.content.size(); i++)
        {
            I el = this.content.remove();
            if(!flag && el.equals(element))
            {
                flag = true;
                oldNums.add(el);
            }
            else
            {
                this.content.add(el);
            }
        }
        if(flag)
        {
            this.content.add(this.content.remove());
        }
    }

    public void moveToBack(I element)
    {
        int size = this.content.size();
        remove(element);
        if(this.content.size() < size)
        {
            this.content.add(element);
        }
    }
}
