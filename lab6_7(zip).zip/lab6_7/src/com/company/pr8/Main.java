package com.company.pr8;

import java.util.ArrayList;

public class Main
{

    public static void main(String[] args)
    {
        UnfairWaitList a = new UnfairWaitList();
        ArrayList b = new ArrayList();
        BoundedWaitList c = new BoundedWaitList(10);

        c.add(7);
        c.add(8);
        c.remove();

        a.add(0);
        a.add(1);
        a.add(2);
        a.add(3);
        a.add(4);
        a.add(5);
        a.add(6);
        a.add(7);
        a.remove(4);
        a.add(4);

        b.add(0);
        b.add(1);
        System.out.println(a.containsAll(b));
        System.out.println(c);
    }
}
