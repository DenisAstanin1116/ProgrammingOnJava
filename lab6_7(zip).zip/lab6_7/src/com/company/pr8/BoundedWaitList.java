package com.company.pr8;

public class BoundedWaitList <I> extends WaitList<I>
{
    private int capacity;

    public BoundedWaitList(int capacity)
    {
        super();
        if (capacity <= 0) {
            System.out.println("Размер списка меньше либо равен 0");
            System.exit(0);
        }
        this.capacity = capacity;
    }

    public int getCapacity()
    {
        return capacity;
    }

    public void add(I element)
    {
        if(this.content.size() == capacity) {
            System.out.println("Очередь заполнена");
            System.exit(0);
        }
        this.content.add(element);
    }

    public String toString()
    {
        return "BoundedWaitList capacity: " + capacity + ", components: " + this.content;
    }
}
