package com.company.pr7;

import com.company.pr10.ConcreteFactory;

import java.util.Scanner;
import java.util.Stack;

public class Main {

    public static void main(String[] args) {
        Stack<Integer> s1Temp = new Stack<>();
        Stack<Integer> s1 = new Stack<>();
        Scanner scanner = new Scanner(System.in);
        for(int i=0; i<5; i++){
            s1Temp.push(scanner.nextInt());
        }
        for(int i=0; i<5; i++){
            s1.push(s1Temp.pop());
        }
        Stack<Integer> s2Temp = new Stack<>();
        Stack<Integer> s2 = new Stack<>();

        for(int i=0; i<5; i++){
            s2Temp.push(scanner.nextInt());
        }
        for(int i=0; i<5; i++){
            s2.push(s2Temp.pop());
        }

        int c = 0;
        boolean res = false;
        for (int i = 0; i < 106; i++) {
            c++;
            if (s1.peek() == 9 && s2.peek() == 0){
                s2.add(0, s1.pop());
                s2.add(0, s2.pop());
            }
            else if(s1.peek() == 0 && s2.peek() == 9) {
                s1.add(0, s1.pop());
                s1.add(0, s2.pop());
            }
            else if (s1.peek() > s2.peek()){
                s1.add(0, s1.pop());
                s1.add(0, s2.pop());
            }
            else {
                s2.add(0, s1.pop());
                s2.add(0, s2.pop());
            }
            if (s1.size() == 0) {
                System.out.println("second " + c);
                res = true;
                break;
            }
            if (s2.size() == 0) {
                System.out.println("first " + c);
                res = true;
                break;
            }
        }
        if (!res)
            System.out.println("botva");
    }

}

