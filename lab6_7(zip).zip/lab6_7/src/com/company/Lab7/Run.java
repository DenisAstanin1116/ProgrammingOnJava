package com.company.Lab7;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class Run {
    JFrame fr;
    JPanel jp;
    JLabel label1, label2, label3, label4, label5;
    Font mainFont;

    public void exec() {
        fr = new JFrame();
        fr.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        fr.setSize(900, 600);
        fr.setVisible(true);

        jp = new JPanel();
        jp.setLayout(new BorderLayout());
        jp.setBackground(new Color(0, 0, 0));

        mainFont = new Font("Consolas", Font.BOLD, 20);

        label1 = new JLabel("SOUTH");
        label1.setPreferredSize(new Dimension(900, 150));
        label1.setBackground(new Color(24,231,139));
        label1.setHorizontalAlignment(SwingConstants.CENTER);
        label1.setVerticalAlignment(SwingConstants.CENTER);
        label1.setFont(mainFont);
        label1.setVisible(true);
        label1.setOpaque(true);

        label1.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                JOptionPane.showMessageDialog(null, "Добро пожаловать Абха");
            }
        });

        label2 = new JLabel("NORTH");
        label2.setPreferredSize(new Dimension(900, 150));
        label2.setBackground(new Color(22,138,176));
        label2.setHorizontalAlignment(SwingConstants.CENTER);
        label2.setVerticalAlignment(SwingConstants.CENTER);
        label2.setFont(mainFont);
        label2.setVisible(true);
        label2.setOpaque(true);

        label2.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                JOptionPane.showMessageDialog(null, "Добро пожаловать в");
            }
        });

        label3 = new JLabel("EAST");
        label3.setPreferredSize(new Dimension(300, 200));
        label3.setBackground(new Color(141,220,222));
        label3.setHorizontalAlignment(SwingConstants.CENTER);
        label3.setVerticalAlignment(SwingConstants.CENTER);
        label3.setFont(mainFont);
        label3.setVisible(true);
        label3.setOpaque(true);

        label3.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                JOptionPane.showMessageDialog(null, "Добро пожаловать в Дахране");
            }
        });

        label4 = new JLabel("WEST");
        label4.setPreferredSize(new Dimension(300, 200));
        label4.setBackground(new Color(51,176,88));
        label4.setHorizontalAlignment(SwingConstants.CENTER);
        label4.setVerticalAlignment(SwingConstants.CENTER);
        label4.setFont(mainFont);
        label4.setVisible(true);
        label4.setOpaque(true);

        label4.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                JOptionPane.showMessageDialog(null, "Добро пожаловать в Джидда");
            }
        });

        label5 = new JLabel("CENTER");
        label5.setPreferredSize(new Dimension(300, 200));
        label5.setBackground(new Color(28,59,94));
        label5.setHorizontalAlignment(SwingConstants.CENTER);
        label5.setVerticalAlignment(SwingConstants.CENTER);
        label5.setFont(mainFont);
        label5.setVisible(true);
        label5.setOpaque(true);

        label5.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                JOptionPane.showMessageDialog(null, "Добро пожаловать в");
            }
        });

        jp.add(label1, BorderLayout.SOUTH);
        jp.add(label2, BorderLayout.NORTH);
        jp.add(label3, BorderLayout.EAST);
        jp.add(label4, BorderLayout.WEST);
        jp.add(label5, BorderLayout.CENTER);
        fr.add(jp);
    }
}
