package com.company.Lab7;

public class Main {

    public static void main(String[] args) {
        Run a = new Run();
        a.exec();
    }
}
